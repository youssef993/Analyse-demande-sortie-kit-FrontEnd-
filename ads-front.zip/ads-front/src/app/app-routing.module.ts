import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ListMonquantComponent} from './list-monquant/list-monquant.component';
import {AddDemandeComponent} from './add-demande/add-demande.component';
import {ListFilterComponent} from './list-filter/list-filter.component';
import {ChoixIlotComponent} from './choix-ilot/choix-ilot.component';
import {ListKitComponent} from './list-kit/list-kit.component';
import {AddKitComponent} from './add-kit/add-kit.component';
import {ChoixIlotKitComponent} from './choix-ilot-kit/choix-ilot-kit.component';
import {LoginComponent} from './login/login.component';
import {AuthenticationGuard} from './shared/auth/authentication.guard';


const routes: Routes = [
  {path: '', redirectTo: 'list-filter', pathMatch:'full',canActivate: [AuthenticationGuard]},
  {path: 'list-monquant', component: ListMonquantComponent, canActivate: [AuthenticationGuard]},
  {path: 'list-kit', component: ListKitComponent, canActivate: [AuthenticationGuard]},
  {path: 'list-kit-etat/:etat', component: ListKitComponent, canActivate: [AuthenticationGuard]},
  {path: 'list-kit-product/:produit/:of', component: ListKitComponent, canActivate: [AuthenticationGuard]},
  {path: 'list-kit-ilot/:ilot', component: ListKitComponent, canActivate: [AuthenticationGuard]},
  {path: 'add-kit', component: AddKitComponent, canActivate: [AuthenticationGuard]},
  {path: 'edit-kit/:id', component: AddKitComponent, canActivate: [AuthenticationGuard]},
  {path: 'add-demande', component: AddDemandeComponent, canActivate: [AuthenticationGuard]},
  {path: 'edit-demande/:id', component: AddDemandeComponent, canActivate: [AuthenticationGuard]},
  {path: 'list-monquant-ilot/:ilot', component: ListMonquantComponent, canActivate: [AuthenticationGuard]},
  {path: 'list-monquant-etat/:etat', component: ListMonquantComponent, canActivate: [AuthenticationGuard]},
  {path: 'choix-ilot', component: ChoixIlotComponent, canActivate: [AuthenticationGuard]},
  {path: 'choix-ilot-kit', component: ChoixIlotKitComponent, canActivate: [AuthenticationGuard]},
  {path: 'list-filter', component: ListFilterComponent, canActivate: [AuthenticationGuard]},
  {path: 'login', component: LoginComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
