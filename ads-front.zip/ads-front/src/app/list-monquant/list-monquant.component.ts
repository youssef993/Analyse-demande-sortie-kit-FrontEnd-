import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {ProduitService} from '../shared/services/produit.service';
import {Produits} from '../shared/model/produits';
import {ConfirmationService, MessageService} from 'primeng/api';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-list-monquant',
  templateUrl: './list-monquant.component.html',
  styleUrls: ['./list-monquant.component.css']
})
export class ListMonquantComponent implements OnInit {

  prods: Produits[];
  cols: any[];
  columns: any[];
  exportColumns: any[];
  constructor(private produitService: ProduitService, private messageService: MessageService,
              private router: Router, private confirmationService: ConfirmationService, private activatedRoot: ActivatedRoute) { }

  ngOnInit() {
    const ilot = this.activatedRoot.snapshot.paramMap.get('ilot');
    const etat = this.activatedRoot.snapshot.paramMap.get('etat');

    if (ilot !== null) {
      this.produitService.findByIlot(ilot).subscribe( res => {
        this.prods = res; }, ex => {
        console.log(ex);
      });
    } else if (etat !== null) {
      this.produitService.findByEtat(etat).subscribe( res => {
        this.prods = res; }, ex => {
        console.log(ex);
      });
    } else {
      this.getAll();
    }
  }
    getAll() {
    this.produitService.getAll()
      .subscribe(data => {
        this.prods = data;
        console.log(data); }, err => {
        console.log(err);
      });
  }
public supprimer(produit) {
    this.confirmationService.confirm({
      header: 'Confirmation',
      message: 'VOULEZ VOUS SUPPRIMER!!!',
      accept: () => {
        this.produitService.delete(produit.id).subscribe( res => {if (res.success) {
          this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
          this.getAll();
        } else {
          this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
        }
        }, err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });

      }
    });

}
public editer(produit) {
    this.router.navigate(['/edit-demande', produit.id]);

}
}
