import { AuthorityDirective } from './authority.directive';

describe('AuthorityDirective', () => {
  it('should create an instance', () => {
    const directive = new AuthorityDirective();
    expect(directive).toBeTruthy();
  });
});
