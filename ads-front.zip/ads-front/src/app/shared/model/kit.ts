export class Kit {
  id: number;
  product: string;
  oef: string;
  etats: string;
  dates: string;
  ilots: string
}
