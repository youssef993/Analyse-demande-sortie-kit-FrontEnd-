export class Produits {
  id: number;
  produit: string;
  of: string;
  composant: string;
  ilot: string;
  date: string;
  etat: string;
  impt: string;
  numLot: string;
  numLotS: string;
  cause: string;
}
