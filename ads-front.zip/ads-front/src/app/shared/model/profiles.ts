export class Profiles {
  id: number;
  username: string;
  password: string;
  role: string;
}
