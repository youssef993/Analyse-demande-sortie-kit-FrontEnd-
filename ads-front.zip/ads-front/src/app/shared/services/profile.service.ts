import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../../environments/environment';
import {Observable} from 'rxjs';
import {Profiles} from '../model/profiles';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
private url = environment.baseUrl + '/profile';
  constructor(private httpClient: HttpClient) { }

  public getAll(): Observable<any> {
    return this.httpClient.get<Profiles[]>(this.url);
  }
  public save(profile: Profiles): Observable<any>{
    return this.httpClient.post(this.url, profile);
  }
  public update(profile: Profiles): Observable<any>{
    return this.httpClient.put(this.url, profile);
  }
  public delete(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);
  }
  public getById(id) : Observable<any>{
    return this.httpClient.get<Profiles>(this.url + '/' + id);
  }
}
