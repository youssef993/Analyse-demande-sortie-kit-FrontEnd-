import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Produits} from '../model/produits';
import {environment} from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProduitService {
private  url = environment.baseUrl + '/produit';

  constructor(private httpClient: HttpClient) { }

  public getAll(): Observable<Produits[]>{
    return this.httpClient.get<Produits[]>(this.url);
  }

  public save(produit: Produits): Observable<any>{
  return this.httpClient.post(this.url, produit);
  }

  public update(produit: Produits): Observable<any>{
    return this.httpClient.put(this.url, produit);
  }

  public delete(id): Observable<any>{
    return this.httpClient.delete(this.url + '/' + id);
  }
  public findById(id): Observable<Produits> {
    return this.httpClient.get<Produits>(this.url + '/' + id);
  }

  public findByIlot(ilot): Observable<Produits[]>{
    return this.httpClient.get<Produits[]>(this.url + '/Produits' + '/' + ilot);
  }
  public findByEtat(etat): Observable<Produits[]>{
    return this.httpClient.get<Produits[]>(this.url + '/Prod' + '/' + etat);
  }
  public findValide(): Observable<Produits[]>{
    return this.httpClient.get<Produits[]>(this.url + '/Prod' + '/validé');
  }
  public findNonValide(): Observable<Produits[]>{
    return this.httpClient.get<Produits[]>(this.url + '/Prod' + '/demande');
  }



}
