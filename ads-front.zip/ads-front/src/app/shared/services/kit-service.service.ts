import { Injectable } from '@angular/core';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Kit} from '../model/kit';


@Injectable({
  providedIn: 'root'
})
export class KitServiceService {
  private  url = environment.baseUrl + '/Kit';
  constructor(private httpClient: HttpClient) { }

  public findAll(): Observable<any> {
   return this.httpClient.get(this.url);
  }
  public add(kit: Kit): Observable<any> {
    return this.httpClient.post(this.url, kit);
  }
  public miseajour(kit: Kit): Observable<any> {
    return this.httpClient.put(this.url, kit);
  }
  public supp(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);
  }
  public getByEtat(etats): Observable<Kit[]> {
    return this.httpClient.get<Kit[]>(this.url + '/kit' + '/' + etats);
  }
  public getByProductAndOef(product, oef): Observable<Kit[]> {
    return this.httpClient.get<Kit[]>(this.url + '/' + product + '/' + oef);
}
  public getById(id): Observable<Kit> {
    return this.httpClient.get<Kit>(this.url + '/' + id);
  }
  public getByIlots(ilots): Observable<Kit[]>{
    return this.httpClient.get<Kit[]>(this.url + '/kits' + '/' + ilots);
  }
}
