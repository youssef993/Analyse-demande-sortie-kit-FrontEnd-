import { Component, OnInit } from '@angular/core';
import {KitServiceService} from '../shared/services/kit-service.service';
import {ConfirmationService, MessageService} from 'primeng/api';
import {Router} from '@angular/router';
import {Kit} from '../shared/model/kit';

@Component({
  selector: 'app-choix-ilot-kit',
  templateUrl: './choix-ilot-kit.component.html',
  styleUrls: ['./choix-ilot-kit.component.css']
})
export class ChoixIlotKitComponent implements OnInit {

  ilots: any[];
  ilot:any;
  produit: any;
  etats: any[];
  oef:any;
  etat: any;
  selectedIlot: any;
  selectedEtat: any;
  var1 = 'demande';
  var2 = 'validé';
  var3 = 'bloqué';
  var4= 'réalisé';
  var5= 'Kit réceptionner';
  kit: Kit[];

  constructor(private kitService: KitServiceService, private messageService: MessageService,
              private router: Router, private confirmationService: ConfirmationService) { }

  ngOnInit() {
    this.ilots = [{ilot: 'classique'}, {ilot: 'montage mécanique'}, {ilot: 'grand platine'}, {ilot: 'A380'}, {ilot: 'A320'}, {ilot: 'toron Finie'}];
    this.etats = [{etat: this.var1}, {etat: this.var2}, {etat: this.var3}, {etat: this.var4}, {etat: this.var5}];
  }
  public getByIlots(selectedIlot) {

    this.router.navigate(['list-kit-ilot/',  this.selectedIlot.ilot]);
  }
  public getByEtat(selectedEtat) {
    this.router.navigate(['list-kit-etat/',  this.selectedEtat.etat]);
  }
  public getByProduitAndof(produit, oef) {
    this.router.navigate(['list-kit-product/', this.produit, this.oef]);
  }
  public getValide() {
    this.router.navigate(['list-kit-etat/', this.var2]);
  }
  public getNonValide() {
    this.router.navigate(['list-kit-etat/', this.var1]);
  }
  public getRealise() {
    this.router.navigate(['list-kit-etat/', this.var4]);
  }
  public getNonRealise() {
    this.router.navigate(['list-kit-etat/', this.var3]);
  }
  public getMiseEnProd(){
    this.router.navigate(['list-kit-etat/', this.var5]);
  }

}
