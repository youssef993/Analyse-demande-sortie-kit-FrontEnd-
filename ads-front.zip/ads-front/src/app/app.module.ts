import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { ListMonquantComponent } from './list-monquant/list-monquant.component';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import { AddDemandeComponent } from './add-demande/add-demande.component';
import { ChoixIlotComponent } from './choix-ilot/choix-ilot.component';
import { ListFilterComponent } from './list-filter/list-filter.component';
import {InputTextModule} from 'primeng/inputtext';
import {KeyFilterModule} from 'primeng/keyfilter';
import {MessageModule} from 'primeng/message';
import {ConfirmationService, MessageService} from 'primeng/api';
import {ToastModule} from 'primeng/toast';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {DropdownModule} from 'primeng/dropdown';
import { ListKitComponent } from './list-kit/list-kit.component';
import { AddKitComponent } from './add-kit/add-kit.component';
import { ChoixIlotKitComponent } from './choix-ilot-kit/choix-ilot-kit.component';
import { LoginComponent } from './login/login.component';
import {JwtInterceptorService} from './shared/auth/jwt-interceptor.service';
import { AuthorityDirective } from './shared/directives/authority.directive';


@NgModule({
  declarations: [
    AppComponent,
    ListMonquantComponent,
    AddDemandeComponent,
    ChoixIlotComponent,
    ListFilterComponent,
    ListKitComponent,
    AddKitComponent,
    ChoixIlotKitComponent,
    LoginComponent,
    AuthorityDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    TableModule,
    ButtonModule,
    InputTextModule,
    KeyFilterModule,
    MessageModule,
    ToastModule,
    BrowserAnimationsModule,
    ConfirmDialogModule,
    DropdownModule

  ],
  providers: [MessageService, ConfirmationService, {provide: HTTP_INTERCEPTORS, useClass: JwtInterceptorService, multi: true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
