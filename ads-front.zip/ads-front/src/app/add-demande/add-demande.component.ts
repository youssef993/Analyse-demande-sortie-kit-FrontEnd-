import { Component, OnInit } from '@angular/core';
import {Produits} from '../shared/model/produits';
import {ProduitService} from '../shared/services/produit.service';
import {MessageService} from 'primeng/api';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-add-demande',
  templateUrl: './add-demande.component.html',
  styleUrls: ['./add-demande.component.css']
})
export class AddDemandeComponent implements OnInit {
ilots: any[];
impts: any[];
  selectedIlot: any;
  selectedImpt: any;
 prod: Produits = new Produits();
 acc = false;
 nacc = true;
  var1 = 'validé';
  var2 = 'réalisé';
  var3 = 'mise en prod';
  var4 = 'non réaliser';
  constructor(private produitService: ProduitService,
              private messageService: MessageService, private router: Router,
              private activatedRoot: ActivatedRoute) { }

  ngOnInit() {
    this.ilots = [{ilot: 'classique'}, {ilot: 'montage mécanique'}, {ilot: 'grand platine'}, {ilot: 'A380'}, {ilot: 'A320'}, {ilot: 'toron Finie'}];
    this.impts = [{impt: 'Contenu/Contenant'}, {impt: 'Comptage'}, {impt: 'Nomenclature'}, {impt: 'Non Conformité fornisseur'}, {impt: 'Rebut'}];
    const id = this.activatedRoot.snapshot.paramMap.get('id');
    if (id !== null) {
      this.acc = true;
      this.nacc = false;
      this.produitService.findById(id).subscribe( res => {
        this.prod = res; }, ex => {
        console.log(ex);
      });
    } else {
      this.acc = false;
    }
  }
  ajouter() {
    this.prod.ilot = this.selectedIlot.ilot;
    this.prod.impt = this.selectedImpt.impt;
    this.prod.etat = 'demande';
    this.prod.date = new Date().toLocaleDateString() + '-'  + new Date().toLocaleTimeString();
    this.produitService.save(this.prod).subscribe(res => {
      if (res.success) {
        this.router.navigate(['/list-monquant']);
        this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
      } else {

        this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
      }
    }, err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });

  }
  valider() {
    this.prod.etat = this.var1;
    this.prod.date = new Date().toLocaleDateString() + '-'  + new Date().toLocaleTimeString();
    this.produitService.update(this.prod).subscribe(res => {
      if (res.success) {
        this.router.navigate(['/list-monquant']);
        this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
      } else {

        this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
      }
    }, err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });
  }
  realiser() {
    this.prod.etat = this.var2;
    this.prod.date = this.prod.date + '  réaliser le  ' + new Date().toLocaleDateString() + '-'  + new Date().toLocaleTimeString();
    this.produitService.update(this.prod).subscribe(res => {
      if (res.success) {
        this.router.navigate(['/list-monquant']);
        this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
      } else {

        this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
      }
    }, err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });
  }
  bloquer() {
    this.prod.etat = this.var4;
    this.prod.date = this.prod.date + '  bloqué a cause de  ' + this.prod.cause;
    this.produitService.update(this.prod).subscribe(res => {
      if (res.success) {
        this.router.navigate(['/list-monquant']);
        this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
      } else {

        this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
      }
    }, err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });
  }

  miseEnProd() {
    this.prod.etat = this.var3;
    this.produitService.update(this.prod).subscribe(res => {
      if (res.success) {
        this.router.navigate(['/list-monquant']);
        this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
      } else {

        this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
      }
    }, err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });
  }
}
