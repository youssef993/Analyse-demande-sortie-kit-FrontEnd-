import { Component, OnInit } from '@angular/core';
import {Produits} from '../shared/model/produits';
import {ProduitService} from '../shared/services/produit.service';
import {ConfirmationService, MessageService} from 'primeng/api';
import {ActivatedRoute, Router} from '@angular/router';
import {KitServiceService} from '../shared/services/kit-service.service';
import {Kit} from '../shared/model/kit';

@Component({
  selector: 'app-list-kit',
  templateUrl: './list-kit.component.html',
  styleUrls: ['./list-kit.component.css']
})
export class ListKitComponent implements OnInit {
  kit: Kit[];
  constructor(private kitService: KitServiceService, private messageService: MessageService,
              private router: Router, private confirmationService: ConfirmationService, private activatedRoot: ActivatedRoute) { }

  ngOnInit() {

    const etat = this.activatedRoot.snapshot.paramMap.get('etat');
    const prod = this.activatedRoot.snapshot.paramMap.get('produit');
    const of = this.activatedRoot.snapshot.paramMap.get('of');
    const ilot = this.activatedRoot.snapshot.paramMap.get('ilot');

    if (etat !== null) {
      this.kitService.getByEtat(etat).subscribe( res => {
        this.kit = res; }, ex => {
        console.log(ex);
      });
    } else if(prod!== null && of !==null){
      this.kitService.getByProductAndOef(prod, of).subscribe(res => {
        this.kit = res; }, ex => {
        console.log(ex);
      });
    }else if (ilot != null){
      this.kitService.getByIlots(ilot).subscribe(res => {
        this.kit = res; }, ex => {
        console.log(ex);
      });
    }
    else{
      this.getAll();
    }


  }
  getAll() {
    this.kitService.findAll()
      .subscribe(data =>{
        this.kit = data
        console.log(data);}, err =>{
        console.log(err);
      });
  }
  public supprimer(kit){
    this.confirmationService.confirm({
      header: 'Confirmation',
      message: 'VOULEZ VOUS SUPPRIMER!!!',
      accept: () => {
        this.kitService.supp(kit.id).subscribe( res => {if (res.success) {
          this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
          this.getAll();
        } else {
          this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
        }
        }, err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });

      }
    });

  }
  public editer(kit){
    this.router.navigate(['/edit-kit', kit.id]);

  }


}
