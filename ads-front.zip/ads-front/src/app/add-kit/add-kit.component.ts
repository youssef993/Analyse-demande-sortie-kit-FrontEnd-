import { Component, OnInit } from '@angular/core';
import {Kit} from '../shared/model/kit';
import {MessageService} from 'primeng/api';
import {ActivatedRoute, Router} from '@angular/router';
import {KitServiceService} from '../shared/services/kit-service.service';

@Component({
  selector: 'app-add-kit',
  templateUrl: './add-kit.component.html',
  styleUrls: ['./add-kit.component.css']
})
export class AddKitComponent implements OnInit {
kit: Kit = new Kit();
ilots: any[];
varr = false;
  selectedIlot: any;
  constructor(private kitService: KitServiceService,
              private messageService: MessageService, private router: Router,
              private activatedRoot: ActivatedRoute) { }

  ngOnInit() {
    this.ilots = [{ilot: 'classique'}, {ilot: 'montage mécanique'}, {ilot: 'grand platine'}, {ilot: 'A380'}, {ilot: 'A320'}, {ilot: 'toron Finie'}];
    const id = this.activatedRoot.snapshot.paramMap.get('id');
    const etat = this.activatedRoot.snapshot.paramMap.get('etats');

    if (id !== null) {
      this.varr = true;
      this.kitService.getById(id).subscribe( res => {
        this.kit = res;
        }, ex => {
        console.log(ex);
      });
    }
  }

 ajouter() {
   this.kit.ilots = this.selectedIlot.ilot;
   this.kit.etats = 'demande';
   this.kit.dates = new Date().toLocaleDateString() + '-'  + new Date().toLocaleTimeString();
   this.kitService.add(this.kit).subscribe(res => {
      if (res.success) {
          this.router.navigate(['/list-kit']);
          this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
                        } else {

         this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
                                }
                                                      },
      err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });
          }
  valider() {
    this.kit.etats = 'validé';
    this.kitService.miseajour(this.kit).subscribe(res => {
      if (res.success) {
        this.router.navigate(['/list-kit']);
        this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
      } else {

        this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
      }
    }, err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });
  }

  realiser() {
    this.kit.etats = 'réalisé';
    this.kit.dates = 'Kit réaliser le  ' + new Date().toLocaleDateString() + '-'  + new Date().toLocaleTimeString();
    this.kitService.miseajour(this.kit).subscribe(res => {
      if (res.success) {
        this.router.navigate(['/list-monquant']);
        this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
      } else {

        this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
      }
    }, err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });
  }
  bloquer() {
    this.kit.etats = 'bloqué';
    this.kitService.miseajour(this.kit).subscribe(res => {
      if (res.success) {
        this.router.navigate(['/list-monquant']);
        this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
      } else {

        this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
      }
    }, err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });
  }

  miseEnProd() {
    this.kit.etats = 'Kit réceptionner';
    this.kitService.miseajour(this.kit).subscribe(res => {
      if (res.success) {
        this.router.navigate(['/list-kit']);
        this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
      } else {

        this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
      }
    }, err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });
  }

}
