import { Component, OnInit } from '@angular/core';
import {Profiles} from '../shared/model/profiles';
import {AuthenticationService} from '../shared/auth/authentication.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  profile: Profiles = new Profiles();
  constructor(private authenticationService: AuthenticationService,
              private router: Router) { }

  ngOnInit() {
  }
 authenticate() {
    this.authenticationService.authenticate(this.profile).subscribe(res => {
      const token = res.headers.get('Authorization');
      localStorage.setItem('token', token);
      this.router.navigate(['/list-filter']);
    }, err => {
      console.log(err);
    });
 }
}
