import { Component, OnInit } from '@angular/core';
import {Produits} from '../shared/model/produits';
import {ProduitService} from '../shared/services/produit.service';
import {ConfirmationService, MessageService} from 'primeng/api';
import {Router} from '@angular/router';

@Component({
  selector: 'app-choix-ilot',
  templateUrl: './choix-ilot.component.html',
  styleUrls: ['./choix-ilot.component.css']
})
export class ChoixIlotComponent implements OnInit {


  ilots: any[];
  etats: any[];
  ilot:any;
  etat: any;
  selectedIlot: any;
  selectedEtat: any;
  var1 = 'validé';
  var2 = 'demande';
  var3 = 'réalisé';
  var4= 'mise en prod';
  var5= 'non réaliser';
  prod: Produits[];
  constructor(private produitService: ProduitService, private messageService: MessageService,
              private router: Router, private confirmationService: ConfirmationService) { }

  ngOnInit() {
    this.ilots = [{ilot: 'classique'}, {ilot: 'montage mécanique'}, {ilot: 'grand platine'}, {ilot: 'A380'}, {ilot: 'A320'}, {ilot: 'toron Finie'}];
    this.etats = [{etat: this.var1}, {etat: this.var2}, {etat: this.var3}, {etat: this.var4}];
  }
  public getByIlot(selectedIlot) {

    this.router.navigate(['list-monquant-ilot/',  this.selectedIlot.ilot]);
  }
  public getByEtat(selectedEtat) {
    this.router.navigate(['list-monquant-etat/',  this.selectedEtat.etat]);
  }
  public getValide() {
    this.router.navigate(['list-monquant-etat/', this.var1]);
  }
  public getNonValide() {
    this.router.navigate(['list-monquant-etat/', this.var2]);
  }
  public getRealise() {
    this.router.navigate(['list-monquant-etat/', this.var3]);
  }
  public getNonRealise() {
    this.router.navigate(['list-monquant-etat/', this.var5]);
  }
  public getMiseEnProd(){
    this.router.navigate(['list-monquant-etat/', this.var4]);
  }


}
